"""ARC-AGI-3 Genetic Baby V4 - 5-Layer Cognitive Architecture."""

__version__ = "0.1.0"
__all__ = [
    "ARCGeneticBabyV4",
    "PredictivePerception",
    "ActiveInferenceAgent", 
    "EvolutionaryProgramSynthesizer",
    "StructuralAnalogyEngine",
    "SleepConsolidation",
    "GeneticEnsemble",
    "RelationalMemory",
    "AgentConfig",
]

from .agent import ARCGeneticBabyV4
from .config import AgentConfig
from .perception import PredictivePerception
from .active_inference import ActiveInferenceAgent
from .program_synthesis import EvolutionaryProgramSynthesizer
from .analogy import StructuralAnalogyEngine
from .sleep import SleepConsolidation, GeneticEnsemble
from .memory import RelationalMemory
